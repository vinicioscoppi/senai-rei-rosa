import React, { Component } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  Button,
  TouchableHighlight,
} from 'react-native';
import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import ChooseClass from './screens/ChooseClass/View/chooseClass'
import AtributeScreen from './screens/AtributeScreen/View/atributeScreen'
export default class App extends Component {
  render() {
    return (
      <AtributeScreen></AtributeScreen>
    );
  }
}
