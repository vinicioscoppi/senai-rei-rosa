import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
    atributes: {
        backgroundColor: '#ffffff',
        // flex:1 does not allow buttons to work?
        flexDirection:'row',
    },
    atributeCell: {
        height:60,
        width:70,
        borderColor:'black',
        borderWidth:2,
        marginTop:-1,
    },
    atributeBar: {
        height:410, // Emulador
        //height:410, // Meizu M5c
        width:103, // Emulador
        //width:90, // Meizu M5c
        textAlign:'center',
        borderColor:'black',
        //borderWidth:3,
        left:0,
        alignItems:'center',
        paddingTop:10,
    },
    atributeBarTitle:{
        position:'relative',
        bottom:-10,
        //borderWidth:2,
    }
});