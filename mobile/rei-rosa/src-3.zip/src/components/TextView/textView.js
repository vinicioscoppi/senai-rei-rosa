import React, {Component} from 'react';
import {
  StyleSheet,
  View,
  Text,
} from 'react-native';
import { styles } from './textView-styles';

export class TextView extends Component
{
    constructor(props){
        super(props);
    }
    render()
    {
        return(
            <View style={styles.textView}>
                <Text style={styles.text}>
                    {this.props.text}
                </Text>
            </View>
        );
    }
}