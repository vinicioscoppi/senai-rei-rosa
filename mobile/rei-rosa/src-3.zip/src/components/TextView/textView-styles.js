import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
    textView:{
        alignItems:'center',
        justifyContent:'center',
        marginVertical: 30,
        marginHorizontal: 20,
        marginTop: 20,
        height: 80,
    },
    text:{
        color:'black',
        fontSize: 21,
        textAlign:'center',
    }
});