import React, { Component } from 'react';
import {
    SafeAreaView,
    StyleSheet,
    TouchableHighlight,
    View,
    Text,
    Button,
    Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'
import { color } from './../../enums/color';
import { icons } from './../../enums/icons';
import { styles } from './class-styles';
export class Class extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <View style={styles.class}>
                <Icon
                    name={this.props.name}
                    size={this.props.size}
                    color={this.props.color}
                />
            </View>            
        );
    }
}
