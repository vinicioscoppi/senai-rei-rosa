import React, {Component} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  Button,
  TouchableHighlight,
} from 'react-native';
import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import {styles} from './room-styles';
import {maxNumberOfPlayers} from './../../config/roomConfig'
export class Room extends Component
{
    constructor(props){
        super(props);
        this.state = {
            players:this.props.players,
            max:maxNumberOfPlayers
        }
    }
    render()
    {
        return(
            <View style={styles.room}>
                <Text style={styles.roomInfo}>
                    {this.state.players}/{this.state.max}
                </Text>
            </View>
        );
    }
}