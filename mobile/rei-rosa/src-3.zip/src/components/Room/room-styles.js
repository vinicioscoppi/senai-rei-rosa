import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
    room:{
        marginVertical:0,
        marginHorizontal:5,
        height:50,
    },
    roomInfo:{
        color:'black',
        fontSize: 20,
        textAlign:'right',
    }
});