export const maxNumberOfPlayers = 4;
export const roomIcons = ["icon1","icon2","icon3","icon4","icon5","icon6","icon7","icon8","icon9","icon10"]