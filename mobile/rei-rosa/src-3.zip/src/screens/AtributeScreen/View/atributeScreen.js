import React, {Component} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  Button,
  TouchableHighlight,
} from 'react-native';
import { TeamAtributes } from './../../../components/TeamAtribute/teamAtribute'
export default class AtributeScreen extends Component
{
  render()
  {
    return(
      <TeamAtributes>
      </TeamAtributes>
    );
  }
}

