/*

    warnRunOutOfWater()
    warnRunOutOfFood()

    refillWater()
    refillFood()

*/