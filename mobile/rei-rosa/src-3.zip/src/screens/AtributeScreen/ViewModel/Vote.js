/*

    voteAgree()
    voteDisagree()
    
    warnPlayerDisagreed()
    warnRoomAgreed()

*/