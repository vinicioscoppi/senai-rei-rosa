/*

    updateStrenghtPoints()
    updateCouragePoints()
    updateFriendshipPoints()
    updateWisdomPoints()

*/