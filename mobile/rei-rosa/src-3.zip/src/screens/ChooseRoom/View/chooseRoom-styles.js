import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
    textoComando:{
        marginTop:5,
    },
});