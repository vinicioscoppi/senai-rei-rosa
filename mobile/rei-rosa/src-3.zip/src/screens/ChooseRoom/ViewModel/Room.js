/*

    Changing View
        warnRoomIsFull()
        updateRoomTextView()

    Changing Model
        enterRoom() // if enter room, creates player and sets ID

*/