/*

    chooseClass()
    warnClassAlreadyChosen()

*/