/*

    Changing View
        updateRouletteTextView()

    Changing Model
        advanceSquares()

*/