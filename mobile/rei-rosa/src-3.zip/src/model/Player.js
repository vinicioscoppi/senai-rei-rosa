/*

    Atributes
        id
        class
        strenghtPoints
        couragePoints
        friendshipPoints
        wisdowPoints

    Methods
        getId()
        setId()
        
        getClass()
        setClass()

        getStrenghtPoints()
        setStrenghtPoints()

        getCouragePoints()
        setCouragePoints()

        getFriendshipPoints()
        setFriendshipPoints()

        getWisdowPoints()
        setWisdowPoints()
*/