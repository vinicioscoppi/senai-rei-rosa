/*
    Atributes
        text
        effects

    Method
        getText()
        getEffects()
*/