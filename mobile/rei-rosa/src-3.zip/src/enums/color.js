export const color = {
    STRENGTH_DISABLED:'#ffffff',
    STRENGTH_ENABLED:'#cf180e',
    BRAVERY_DISABLED:'#ffffff',
    BRAVERY_ENABLED:'#0f8c16',
    FRIENDSHIP_DISABLED:'#ffffff',
    FRIENDSHIP_ENABLED:'#196dd4',
    WISDOM_DISABLED:'#ffffff',
    WISDOW_ENABLED:'#ffa600',
    WATER:'#1e90ff',
    FOOD:'#ff7105'
}