export const icons = {
    STRENGTH: 'hand-rock-o',
    BRAVERY: 'heart',
    FRIENDSHIP: 'group',
    WISDOW: 'lightbulb-o',
    WATER: 'tint',
    FOOD: 'apple'
}